# Integrated R4 manuscript source

Target: Neural Networks. Internal version R4, 14 November 2026.
Transfer/submission remains incomplete.

Compile in this directory using a standard TeX installation:

    latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex

The verified PDF has 41 pages, seven figures, twelve tables and 17 references.
The original six figures, theory and approved AI declaration are preserved.
R4 integrates r4_methods.tex, r4_results.tex and four r4_*_table.tex inputs.
R3's original diagnostic files remain integrated.
The companion numerical supplement supplies evidence and independent verifiers.
SHA256_MANIFEST.json covers every other file.
